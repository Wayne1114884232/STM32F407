#ifndef __SYS_H
#define __SYS_H	 



#include "stm32f4xx.h"
#include "board.h"
#include "oled.h"
#include "control.h"
#include "encoder.h"
#include "exti.h"
#include "bsp_tb6612.h"
#include "IOI2C.h"
#include "Key.h"
#include "wit_c_sdk.h"
#include "REG.h"
//#include "buzzer.h"
#include "usart3.h"
#include "bsp_ultrasonic.h"
#include "LED.h"
////////////////////////////////////////////////////////////////////////////
#include <string.h> 
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//����һЩ���õ��������Ͷ̹ؼ��� 
typedef int32_t  s32;
typedef int16_t s16;
typedef int8_t  s8;

typedef const int32_t sc32;  
typedef const int16_t sc16;  
typedef const int8_t sc8;  

typedef __IO int32_t  vs32;
typedef __IO int16_t  vs16;
typedef __IO int8_t   vs8;

typedef __I int32_t vsc32;  
typedef __I int16_t vsc16; 
typedef __I int8_t vsc8;   

typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;

typedef const uint32_t uc32;  
typedef const uint16_t uc16;  
typedef const uint8_t uc8; 

typedef __IO uint32_t  vu32;
typedef __IO uint16_t vu16;
typedef __IO uint8_t  vu8;

typedef __I uint32_t vuc32;  
typedef __I uint16_t vuc16; 
typedef __I uint8_t vuc8;


//λ������,ʵ��51���Ƶ�GPIO���ƹ���
//����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).
//IO�ڲ����궨��
// STM32F4
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum))  

#define GPIOA_ODR_Addr    (GPIOA_BASE+0x14) // 0x40020014
#define GPIOB_ODR_Addr    (GPIOB_BASE+0x14) // 0x40020414
#define GPIOC_ODR_Addr    (GPIOC_BASE+0x14) // 0x40020814
#define GPIOD_ODR_Addr    (GPIOD_BASE+0x14) // 0x40020C14
#define GPIOE_ODR_Addr    (GPIOE_BASE+0x14) // 0x40021014
#define GPIOF_ODR_Addr    (GPIOF_BASE+0x14) // 0x40021414    
#define GPIOG_ODR_Addr    (GPIOG_BASE+0x14) // 0x40021814    
#define GPIOH_ODR_Addr    (GPIOH_BASE+0x14) // 0x40021C14    
#define GPIOI_ODR_Addr    (GPIOI_BASE+0x14) // 0x40022014    

#define GPIOA_IDR_Addr    (GPIOA_BASE+0x10) // 0x40020010
#define GPIOB_IDR_Addr    (GPIOB_BASE+0x10) // 0x40020410
#define GPIOC_IDR_Addr    (GPIOC_BASE+0x10) // 0x40020810
#define GPIOD_IDR_Addr    (GPIOD_BASE+0x10) // 0x40020C10
#define GPIOE_IDR_Addr    (GPIOE_BASE+0x10) // 0x40021010
#define GPIOF_IDR_Addr    (GPIOF_BASE+0x10) // 0x40021410
#define GPIOG_IDR_Addr    (GPIOG_BASE+0x10) // 0x40021810
#define GPIOH_IDR_Addr    (GPIOH_BASE+0x10) // 0x40021C10
#define GPIOI_IDR_Addr    (GPIOI_BASE+0x10) // 0x40022010
 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //���� 

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //��� 
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //���� 

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //��� 
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //����

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //��� 
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //����

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //��� 
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //����

/////////////////////////////////////////////////////////////////
//Ex_NVIC_Configר�ö���
#define GPIO_A 0
#define GPIO_B 1
#define GPIO_C 2
#define GPIO_D 3
#define GPIO_E 4
#define GPIO_F 5
#define GPIO_G 6 

#define FTIR   1  //�½��ش���
#define RTIR   2  //�����ش���

//JTAGģʽ���ö���
#define JTAG_SWD_DISABLE   0X02
#define SWD_ENABLE         0X01
#define JTAG_SWD_ENABLE    0X00	

extern char stop;
//extern u8 Fore,Back,Left,Right;
extern int PWM_MAX,PWM_MIN,a,flag_Num,flag_Num1,flag_a,flag_b,flag_c;
extern int MOTO1,MOTO2,flag_stop,KeyNum,Timer;
extern float pitch,roll,yaw;						//�Ƕ�
extern short gyrox,gyroy,gyroz;					//���ٶ�
extern short aacx,aacy,aacz;						//���ٶ�
extern int Encoder_Left,Encoder_Right;
extern float Track_Kp,Track_Ki,Target_Speed,length;
//extern uint8_t PC14,PC15,PA4,PA5,PA6,PA7,PB0,PB1;
void NVIC_Config(void);
#endif

