#include "control.h"
#include "Tracking.h"

/*Ŀ�ģ����������ӿڣ�ѧϰ�걾�ں�Զ�����ʵ���԰�������Ʃ��ƽ��С����Ѳ�ߡ�׷�������𵽰������á�*/

#define ACC_UPDATE		0x01
#define GYRO_UPDATE		0x02
#define ANGLE_UPDATE	0x04
#define MAG_UPDATE		0x08
#define READ_UPDATE		0x80

static volatile char s_cDataUpdate = 0, s_cCmd = 0xff;
void CopeSensorData(uint32_t uiReg, uint32_t uiRegNum);

float Med_Angle=0;			//��е��ֵ��---�������޸���Ļ�е��ֵ���ɡ�
float Target_Speed=0;	//�����ٶȣ���������---���ο����ӿڣ����ڿ���С��ǰ�����˼����ٶȡ�
float Turn_Speed=0;			//�����ٶȣ�ƫ����

float
	Vertical_Kp=100,//280,//270,//+
	Vertical_Kd=0;//23;//23;//+
float
	Velocity_Kp=-0,//-125,//-120,//-
	Velocity_Ki=-0;//-0.625;//-0.6;//-
float
	Turn_Kd=0,//+
	Turn_Kp=0;//

float 
	Track_Kp=0,			//180
	Track_Ki=0,			//1
	Track_Kd=0;			//+ ����ת�򻷵�Kd

float  
	diffe_kp=0,
  diffe_ki=0,
  diffe_kd=0;

int Vertical_out,Velocity_out,Turn_out,Timer=0;//ֱ����&�ٶȻ�&ת�� ���������
int flag_Num=0,flag_Numdelay=0,Action_speed=0,flag_turn=1,Encoder_S=0;
int flag_a,flag_b,flag_c,flag_Num1,Yaw_Data;
float length;

int Vertical(float Med,float Angle,float gyro_Y);//��������
int Velocity(int Target,int encoder_left,int encoder_right);
int Turn(int gyro_Z,int RC); 
int different_PD(int16_t Encoder_Left,int16_t Encoder_Right,float Gyro_Z);
int16_t Read_turn(int flag_turn);
//void mode1(void);
//void mode2(void);
//void mode3(void);
//void mode4(void);
//void mode5(void);
//void mode6(void);
//void mode7(void);


void TIM7_IRQHandler(void)
{
	int PWM_out;
	Timer++;
	if (TIM_GetITStatus(TIM7,TIM_IT_Update)!= RESET)//һ���ж�
	{
			//1���ɼ�����������&MPU6050�Ƕ���Ϣ��
			Encoder_Left=-Read_Speed(ENCODER_M1);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
			Encoder_Right=-Read_Speed(ENCODER_M2);

			WitReadReg(AX,12);
			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
			
			
			//2��������ѹ��ջ������У�����������������
			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
			Turn_out=Read_turn(flag_turn);																								//ת��
			PWM_out=Vertical_out+Velocity_out;//�������

			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
			MOTO1=PWM_out-Turn_out;//����
			MOTO2=PWM_out+Turn_out;//�ҵ��
			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
	}
//			if((flag_Numdelay==0)&&(Timer>300))
//			{
//				flag_Numdelay=1;
//				Timer=0;
//			}
//			
//			if((KeyNum==1)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=38;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//				}
//			mode1();
//			}
//			if((KeyNum==2)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=38;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//					flag_c=1;
//				}
//			mode2();
//			}
//			if((KeyNum==3)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=35;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//					flag_c=2;
//				}
//			mode3();
//			}
//			if((KeyNum==4)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=30;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//					flag_c=4;
//				}
//			mode4();
//			}
//			if((KeyNum==5)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=38;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//					flag_c=3;
//				}
//			mode5();
//			}
//			if((KeyNum==6)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=38;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//					flag_c=5;
//				}
//			mode6();
//			}
//			if((KeyNum==7)&&(flag_Numdelay==1))
//			{
//				if(Action_speed==0)
//				{
//					Target_Speed=38;
//					Track_Kp=0;
//					Track_Ki=0;
//					Action_speed=1;
//					flag_c=7;
//				}
//			mode7();
//			}	
//	length = Hcsr04GetLength();
	LED1_Toggle();
	TIM_ClearITPendingBit(TIM7, TIM_IT_Update);//����жϱ�־λ
}

/*********************
ֱ����PD��������Kp*Ek+Kd*Ek_D

��ڣ������Ƕȡ���ʵ�Ƕȡ���ʵ���ٶ�
���ڣ�ֱ�������
*********************/
int Vertical(float Med,float Angle,float gyro_Y)
{
	int PWM_out;
	
	PWM_out=Vertical_Kp*(Angle-Med)+Vertical_Kd*(gyro_Y-0);
	return PWM_out;
}

/*********************
�ٶȻ�PI��Kp*Ek+Ki*Ek_S
*********************/
int Velocity(int Target,int encoder_left,int encoder_right)
{
	static int PWM_out,Encoder_Err,EnC_Err_Lowout,EnC_Err_Lowout_last;
	float a=0.8;
	
	//1.�����ٶ�ƫ��
	Encoder_Err=((encoder_left+encoder_right)-Target);//��ȥ���--�ҵ����⣺�ܹ����ٶ�Ϊ"0"�ĽǶȣ����ǻ�е��ֵ��
	
	//2.���ٶ�ƫ����е�ͨ�˲�
	//low_out=(1-a)*Ek+a*low_out_last;
	EnC_Err_Lowout=(1-a)*Encoder_Err+a*EnC_Err_Lowout_last;//ʹ�ò��θ���ƽ�����˳���Ƶ���ţ���ֹ�ٶ�ͻ�䡣
	EnC_Err_Lowout_last=EnC_Err_Lowout;//��ֹ�ٶȹ����Ӱ��ֱ����������������
	
	//3.���ٶ�ƫ����֣����ֳ�λ��
	Encoder_S+=EnC_Err_Lowout;
	
	//4.�����޷�
	Encoder_S=Encoder_S>10000?10000:(Encoder_S<(-10000)?(-10000):Encoder_S);
	
	if(stop==1)Encoder_S=0,stop=0;//���������
	
	//5.�ٶȻ������������
	PWM_out=Velocity_Kp*EnC_Err_Lowout+Velocity_Ki*Encoder_S;
	return PWM_out;
}

/*********************
ת�򻷣�ϵ��*Z����ٶ�+ϵ��*ң������
*********************/
int Turn(int gyro_Z,int RC)
{
	int PWM_out;
	//�ⲻ��һ���ϸ��PD��������Kd��Ե���ת���Լ������Kp��Ե���ң�ص�ת��
	PWM_out=Turn_Kd*gyro_Z + Turn_Kp*RC;
	return PWM_out;
}
//��ֱ�ߺ�ѭ��
int Track_Turn(float Gyro_Z,int RC)
{
	int PWM_Out;
	float err=0;
	static float Track_s;
	
	err=RC-0;
	Track_s+=err;
	
	PWM_Out=err*Track_Kp+Track_Ki*Track_s+Gyro_Z*Track_Kd;
	return PWM_Out;
}
//����ת//ԭ��ת
int different_PD(int16_t Encoder_Left,int16_t Encoder_Right,float Gyro_Z)
{
	int PWM_OUT,Err;
	static float diff_s;
	
	Err=Encoder_Left-Encoder_Right;
	
	diff_s+=Err;
	
	PWM_OUT=diffe_kp*Err+diffe_ki*diff_s+diffe_kd*Gyro_Z;

	return PWM_OUT;
}

int16_t Read_turn(int flag_turn)
{
	int16_t Value_turn;
	switch(flag_turn)
	{
		case 0:Value_turn=(int16_t)Track_Turn(gyroz,Tracking_InnerRing());break;//ѭ����
		case 1:Value_turn=(int16_t)Turn(gyroz,Turn_Speed);break;								//ԭ��ת
		case 2:Value_turn=(int16_t)different_PD(Encoder_Left,Encoder_Right,gyroz);break;
	}
	return Value_turn;
}
////����B1 B0 A7 A6 A5 A4 C15 C14
////����B1    A7    A5        C14 
//void mode1(void)
//{
//			int PWM_out;
//			if(Timer>=200)
//			{
//				flag_stop=1;
//			}
//			if((KeyNum==1)&&(flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=0;Encoder_S=0;Track_Kp=0;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			if(flag_a==1&&Timer>10)
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				flag_a=0;
//			}
//			
//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}

//void mode2(void)
//{
//			int PWM_out; 
//			
//			if((flag_Num<5)&&(Timer>=250))
//			{
//				flag_stop=1;
//			}
//		
//			if((flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=160;}
//					if(flag_Num1==4){flag_a=1;flag_Num1=5;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=160;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			else if((KeyNum==2)&&(flag_stop==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				if(flag_b==2)
//				{
//					flag_Num+=1;
//					if(flag_Num1==2){flag_a=1;flag_Num1=3;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=50;Track_Kp=0;}
//					if(flag_Num1==6){flag_a=2;flag_Num1=7;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=15;Track_Kp=0;Encoder_S=0;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			if((flag_a==1)&&(Timer>10))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			
//			if((flag_Num1==1)&&(PA4==0)&&(PA5==0)&&(PA6==0)&&(PA7==0))
//			{
//				flag_a=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);
//			}
//			if((flag_Num1==1)&&(Timer>400)&&(PA4==1)&&(PA5==1)&&(PA6==1)&&(PA7==1)&&(PB0==1))
//			{
//				flag_b=2;
//				flag_Num1=2;
//				flag_c=6;
//			}
//			if((flag_Num1==3)&&(Timer>200)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				flag_b=0;		
//				flag_Num1=4;
//			}
//			if((flag_Num1==5)&&(Timer>300)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;
//				flag_Num1=6;
//			}
//			if((flag_Num1==7)&&(Timer>10)&&(flag_a==2))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				flag_a=0;
//			}

//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}

//void mode3(void)
//{
//			int PWM_out; 
//			
//			if((flag_Num<5)&&(Timer>=300))
//			{
//				flag_stop=1;
//			}

//			if((flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=35;Track_Kp=160;}
//					if(flag_Num1==4){flag_a=1;flag_Num1=5;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=160;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			else if((KeyNum==3)&&(flag_stop==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				if(flag_b==2)
//				{				
//					flag_Num+=1;
//					if(flag_Num1==2){flag_a=2;flag_Num1=3;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=5;Track_Kp=0;}
//					if(flag_Num1==6){flag_a=3;flag_Num1=7;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=0;Track_Kp=0;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			if(flag_a==1&&Timer>10)
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			
//			if((flag_Num1==1)&&(Timer==250))
//			{
//				flag_a=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);
//			}
//			if((flag_Num1==1)&&(Timer>300)&&(PB1==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1)&&(PC15==1))
//			{
//				flag_b=2;		
//				flag_Num1=2;
//			}
//			if((flag_a==2)&&(Timer>10)&&(flag_Num1==3))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=-10;
//				flag_a=0;
//				Timer=0;
//				flag_turn=1;
//				Turn_Kp=10;
//				Turn_Speed=45;
//			}
//			if((flag_turn==1)&&(Timer>83))
//			{
//				flag_turn=0;
//				Target_Speed=40;
//				Timer=0;
//				flag_c=6;
//			}
////			if((flag_turn==0)&&(flag_c==6)&&(Timer>400)&&(flag_Num1<4))
////			{
////				flag_a=0;
////				flag_Num1=20;
////				Track_Kp=180;
////				Timer=0;
////			}
//			if((flag_Num1==3)&&(flag_turn==0)&&(Timer>50)&&((PB0==0)|(PA7==0)|(PA6==0)|(PA5==0)|(PA4==0)))
//			{
//				flag_b=0;
//				flag_Num1=4;
//			}
//			if((flag_Num1==5)&&(Timer>100)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;
//				flag_Num1=6;
//				Encoder_S=0;
//			}
//			if((flag_a==3)&&(Timer>10)&&(flag_Num1==7))
//			{
//				Target_Speed=0;
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			
//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}


//void mode4(void)
//{
//			int PWM_out; 
//			
//			if((flag_Num<5)&&(Timer>=300))
//			{
//				flag_stop=1;
//			}
//			
//			if((flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=30;Track_Kp=160;}
//					if(flag_Num1==2){flag_a=2;flag_Num1=3;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=2;Track_Kp=0;Encoder_S=0;}
//					if(flag_Num1==10){flag_a=1;flag_Num1=11;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=160;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;				
//				}
//			}
//			else if((flag_stop==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				if(flag_b==2)
//				{
//					flag_Num+=1;
//					if(flag_Num1==7){flag_a=2;flag_Num1=8;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=5;Track_Kp=0;}
//					if(flag_Num1==12){flag_a=3;flag_Num1=13;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=10;Track_Kp=0;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			if(flag_a==1&&Timer>10)
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			if((flag_Num1==1)&&(Timer>300))
//			{
//				Track_Kp=0;
//			}
//			if((flag_Num1==1)&&(Timer>50)&&(PA6==0)&&(PA5==0)&&(PA7==0)&&(PB0==0))
//			{
//				flag_b=0;
//				flag_Num1=2;
//			}
//			if((flag_a==2)&&(flag_Num1==3)&&(Timer>50))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=3;
//			}
//			if((flag_a==3)&&(Timer>100))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=4;
//			}
//			if((flag_a==4)&&(Timer>150))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=5;
//			}
//			if((Timer>200)&&(flag_a==5))
//			{
//				Target_Speed=5;
//				Track_Kp=160;
//				flag_a=0;
//				Timer=0;
//				flag_Num1=4;
//			}
//			if((flag_Num1==4)&&(flag_a==0)&&(Timer>50))
//			{
//				Target_Speed=-10;
//				Track_Kp=0;
//				Encoder_S=0;
//				Timer=0;
//				flag_Num1=5;
//			}
//			if((flag_Num1==5)&&(Timer>100))
//			{
//				Target_Speed=20;
//				Track_Kp=160;
//				flag_Num1=6;
//				Timer=150;
//			}
//			if((flag_Num1==6)&&(Timer>200)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;
//				flag_Num1=7;
//			}
//			if((flag_Num1==8)&&(Timer>10))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//				Timer=0;
//				flag_Num1=9;
//				flag_turn=1;
//				Target_Speed=-10;
//				Turn_Kp=10;
//				Turn_Speed=45;
//			}
//			if((flag_turn==1)&&(Timer>82))
//			{
//				flag_turn=0;
//				Target_Speed=40;
//				Timer=0;
//				flag_c=6;
//			}
////			if((flag_turn==0)&&(flag_c==6)&&(Timer>400)&&(flag_Num1<10))
////			{
////				flag_a=0;
////				flag_Num1=20;
////				Track_Kp=160;
////				Timer=0;
////			}
//			if((flag_turn==0)&&(Timer>20)&&(flag_Num1==9)&&((PB1==0)|(PB0==0)|(PA7==0)|(PA6==0)|(PA5==0)|(PA4==0)|(PC15==0)|(PC14==0)))
//			{
//				flag_b=0;
//				flag_Num1=10;
//			}
//			if((flag_Num1==11)&&(Timer>200)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;
//				flag_Num1=12;
//				Encoder_S=0;
//			}
//			if((flag_a==3)&&(Timer>10)&&(flag_Num1==13))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				flag_a=0;
//			}

//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}

//void mode5(void)
//{
//			int PWM_out; 
//			
//			if((flag_Num<5)&&(Timer>=250))
//			{
//				flag_stop=1;
//			}
//			if((flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{					
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=35;Track_Kp=150;}
//					if(flag_Num1==6){flag_a=1;flag_Num1=7;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=45;Track_Kp=180;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			else if((flag_stop==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				if(flag_b==2)
//				{
//					flag_Num+=1;
//					if(flag_Num1==4){flag_a=1;flag_Num1=5;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=0;}
//					if(flag_Num1==8){flag_a=2;flag_Num1=9;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=0;Track_Kp=0;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;				
//				}
//			}
//			if(flag_a==1&&Timer>10)
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			
//			if((flag_a==0)&&(flag_Num1==1)&&((Timer>280)|((PA6==0)&&(PA7==0)&&(PA5==0))))//240
//			{
//				GPIO_SetBits(GPIOA,GPIO_Pin_15);
//				flag_Num1=2;
//				Target_Speed=-1;
//				Encoder_S=0;
//				Track_Kp=0;
//				Timer=0;
//				USART2_Send_Data(9);
//			}
//			if((flag_Num1==2)&&(Timer>100))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_Num1=3;
//				flag_b=3;
//			}
//			if((flag_Num1==3)&&(Timer>600)&&(flag_b==3))
//			{
//				Target_Speed=30;
//				Track_Kp=200;
//				flag_b=1;
//				flag_Num1=4;
//				Timer=0;
//			}
//			if((flag_Num1==4)&&(Timer>100)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;
//				flag_Num1=4;
//			}
//			if((flag_Num1==5)&&(Timer>200)&&((PB0==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				flag_b=0;		
//				flag_Num1=6;
//			}
//			if((flag_Num1==7)&&(Timer>300)&&((PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1)))
//			{
//				flag_b=2;
//				flag_Num1=8;
//				Encoder_S=0;
//			}
//			if((flag_a==2)&&(Timer>10)&&(flag_Num1==9))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				flag_a=0;
//			}
//			
//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}
// 
//void mode6(void)
//{
//			int PWM_out; 
//			
//			if((flag_Num<5)&&(Timer>=250))
//			{
//				flag_stop=1;
//			}
//			
//			if((flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=30;Track_Kp=160;}
//					if(flag_Num1==2){flag_a=2;flag_Num1=3;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=2;Track_Kp=0;Encoder_S=0;}
//					if(flag_Num1==10){flag_a=1;flag_Num1=11;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=180;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			else if((flag_stop==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				if(flag_b==2)
//				{
//				flag_Num+=1;
//				if(flag_Num1==8){flag_a=1;flag_Num1=9;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=50;Track_Kp=0;}
//				if(flag_Num1==12){flag_a=3;flag_Num1=13;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=0;Track_Kp=0;}
//				flag_b=1;
//				Timer=0;
//				flag_stop=0;				
//				}
//			}
//			if(flag_a==1&&Timer>10)
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			
//			if((flag_Num1==1)&&(Timer>100)&&(PA7==0)&&(PA5==0)&&(PA6==0))
//			{
//				flag_b=0;
//				flag_Num1=2;
//			}
//			if((flag_a==2)&&(flag_Num1==3)&&(Timer>10))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=3;
//				USART2_Send_Data(9);
//			}
//			if((flag_a==3)&&(Timer>25))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=4;
//			}
//			if((flag_a==4)&&(Timer>50))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=5;
//			}
//			if((flag_a==5)&&(Timer>75))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=6;
//			}
//			if((flag_a==6)&&(Timer>100))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=7;
//			}
//			if((flag_a==7)&&(Timer>125))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=8;
//			}
//			if((flag_a==8)&&(Timer>150))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=9;
//			}
//			if((flag_a==9)&&(Timer>175))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=10;
//			}
//			if((flag_a==10)&&(Timer>200))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=11;
//			}
//			if((flag_a==11)&&(Timer>225))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=12;
//			}
//			if((flag_a==12)&&(Timer>250))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=13;
//			}
//			if((flag_a==13)&&(Timer>275))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=14;
//			}
//			if((flag_a==14)&&(Timer>300))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_Num1=4;
//				flag_a=15;
//			}
//			if((flag_Num1==4)&&(Timer>300))
//			{
//				Target_Speed=5;
//				Timer=0;
//				flag_a=0;
//				flag_Num1=5;
//			}
//			if((flag_Num1==5)&&(Timer>50))
//			{
//				Target_Speed=-10;
//				Encoder_S=0;
//				Timer=0;
//				flag_Num1=6;
//			}
//			if((flag_Num1==6)&&(Timer>100))
//			{
//				Target_Speed=20;
//				flag_c=6;
//				Track_Kp=160;
//				flag_Num1=7;
//				Timer=250;
//			}
//			if((flag_Num1==7)&&(Timer>300)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;		
//				flag_Num1=8;
//			}
//			if((flag_Num1==9)&&(Timer>200)&&((PB1==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				flag_b=0;		
//				flag_Num1=10;
//			}
//			if((flag_Num1==11)&&(Timer>300)&&((PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1)))
//			{
//				flag_b=2;
//				flag_Num1=12;
//				Encoder_S=0;
//			}
//			if((flag_Num1==13)&&(flag_a==3)&&(Timer>20))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				flag_a=0;
//			}

//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}

//void mode7(void)
//{
//			int PWM_out; 
//			
//			if((flag_Num<5)&&(Timer>=250))
//			{
//				flag_stop=1;
//			}
//			
//			if((flag_stop==1)&&((PB0==0)|(PB1==0)|(PA4==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				if(flag_b==0)
//				{
//					flag_Num+=1;
//					if(flag_Num1==0){flag_a=1;flag_Num1=1;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=30;Track_Kp=160;}
//					if(flag_Num1==2){flag_a=1;flag_Num1=3;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=30;Track_Kp=160;}
//					if(flag_Num1==3){flag_a=2;flag_Num1=4;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=2;Track_Kp=0;Encoder_S=0;}
//					if(flag_Num1==11){flag_a=1;flag_Num1=12;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=40;Track_Kp=180;}
//					flag_b=1;
//					Timer=0;
//					flag_stop=0;
//				}
//			}
//			else if((flag_stop==1)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				if(flag_b==2)
//				{
//				flag_Num+=1;
//				if(flag_Num1==9){flag_a=1;flag_Num1=10;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=50;Track_Kp=0;}
//				if(flag_Num1==13){flag_a=3;flag_Num1=14;GPIO_SetBits(GPIOA,GPIO_Pin_15);Target_Speed=0;Track_Kp=0;}
//				flag_b=1;
//				Timer=0;
//				flag_stop=0;				
//				}
//			}
//			if(flag_a==1&&Timer>10)
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				flag_a=0;
//			}
//			
//			if((flag_Num1==1)&&(Timer>100)&&(PA7==0)&&(PA5==0)&&(PA6==0))
//			{
//				flag_b=0;
//				flag_Num1=2;
//				Timer=0;
//			}
//			if((flag_Num1==2)&&(Timer>300)&&(PA5==0)&&(PA6==0)&&(PA7==0))
//			{
//				flag_b=0;
//				flag_Num1=3;
//			}
//			if((flag_a==2)&&(flag_Num1==4)&&(Timer>10))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=3;
//				USART2_Send_Data(9);
//			}
//			if((flag_a==3)&&(Timer>25))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=4;
//			}
//			if((flag_a==4)&&(Timer>50))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=5;
//			}
//			if((flag_a==5)&&(Timer>75))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=6;
//			}
//			if((flag_a==6)&&(Timer>100))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=7;
//			}
//			if((flag_a==7)&&(Timer>125))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=8;
//			}
//			if((flag_a==8)&&(Timer>150))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=9;
//			}
//			if((flag_a==9)&&(Timer>175))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=10;
//			}
//			if((flag_a==10)&&(Timer>200))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=11;
//			}
//			if((flag_a==11)&&(Timer>225))
//			{
//				Target_Speed=1;
//				Encoder_S=0;
//				flag_a=12;
//			}
//			if((flag_a==12)&&(Timer>250))
//			{
//				Target_Speed=2;
//				Encoder_S=0;
//				flag_a=13;
//			}
//			if((flag_a==13)&&(Timer>275))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_a=14;
//			}
//			if((flag_a==14)&&(Timer>300))
//			{
//				Target_Speed=0;
//				Encoder_S=0;
//				flag_Num1=5;
//				flag_a=15;
//			}
//			if((flag_Num1==5)&&(Timer>300))
//			{
//				Target_Speed=5;
//				Track_Kp=160;
//				Timer=0;
//				flag_a=0;
//				flag_Num1=6;
//			}
//			if((flag_Num1==6)&&(Timer>50))
//			{
//				Target_Speed=-10;
//				Track_Kp=0;
//				Encoder_S=0;
//				Timer=0;
//				flag_Num1=7;
//				flag_c=6;
//			}
//			if((flag_Num1==7)&&(Timer>100))
//			{
//				Target_Speed=20;
//				Track_Kp=160;
//				flag_Num1=8;
//				Timer=250;
//			}
//			if((flag_Num1==8)&&(Timer>300)&&(PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1))
//			{
//				flag_b=2;		
//				flag_Num1=9;
//			}
//			if((flag_Num1==10)&&(Timer>200)&&((PB1==0)|(PA5==0)|(PA6==0)|(PA7==0)|(PC15==0)|(PC14==0)))
//			{
//				flag_b=0;		
//				flag_Num1=11;
//			}
//			if((flag_Num1==12)&&(Timer>300)&&((PB0==1)&&(PA7==1)&&(PA6==1)&&(PA5==1)&&(PA4==1)))
//			{
//				flag_b=2;
//				flag_Num1=13;
//				Encoder_S=0;
//			}
//			if((flag_Num1==14)&&(flag_a==3)&&(Timer>20))
//			{
//				GPIO_ResetBits(GPIOA,GPIO_Pin_15);
//				Target_Speed=0;
//				flag_a=0;
//			}

//			Encoder_Left=-Read_Speed(2);//�������԰�װ���պ����180�ȣ�Ϊ�˱������������һ�£�����Ҫ������һ��ȡ����
//			Encoder_Right=-Read_Speed(4);

//			WitReadReg(AX,12);
//			roll=sReg[Roll] / 32768.0f * 180.0f;pitch=sReg[Pitch] / 32768.0f * 180.0f;yaw=sReg[Yaw] / 32768.0f * 180.0f;
//			gyrox=sReg[GX]/ 32768.0f * 2000.0f;gyroy=sReg[GY]/ 32768.0f * 2000.0f;gyroz=sReg[GZ]/ 32768.0f * 2000.0f;
//			aacx=sReg[AX]/ 32768.0f * 16.0f;aacy=sReg[AY]/ 32768.0f * 16.0f;aacz=sReg[AZ]/ 32768.0f * 16.0f;
//			
//			if(s_cDataUpdate & GYRO_UPDATE)s_cDataUpdate &= ~GYRO_UPDATE;
//			if(s_cDataUpdate & ANGLE_UPDATE)s_cDataUpdate &= ~ANGLE_UPDATE;
//			
//			//2��������ѹ��ջ������У�����������������
//			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);								//�ٶȻ�				
//			Vertical_out=Vertical(Med_Angle,roll,gyrox);																	//ֱ����
//			Turn_out=Read_turn(flag_turn);																								//ת��
//			PWM_out=Vertical_out+Velocity_out;//�������

//			//3���ѿ�����������ص�����ϣ�������յĵĿ��ơ�
//			MOTO1=PWM_out-Turn_out;//����
//			MOTO2=PWM_out+Turn_out;//�ҵ��
//			Limit(&MOTO1,&MOTO2);	 //PWM�޷�			
//			Load(MOTO1,MOTO2);		 //���ص�����ϡ�
//			Stop(&Med_Angle,&roll);
//}

void CopeSensorData(uint32_t uiReg, uint32_t uiRegNum)
{
	int i;
    for(i = 0; i < uiRegNum; i++)
    {
        switch(uiReg)
        {
//            case AX:
//            case AY:
            case AZ:
				s_cDataUpdate |= ACC_UPDATE;
            break;
//            case GX:
//            case GY:
            case GZ:
				s_cDataUpdate |= GYRO_UPDATE;
            break;
//            case HX:
//            case HY:
            case HZ:
				s_cDataUpdate |= MAG_UPDATE;
            break;
//            case Roll:
//            case Pitch:
            case Yaw:
				s_cDataUpdate |= ANGLE_UPDATE;
            break;
            default:
				s_cDataUpdate |= READ_UPDATE;
			break;
        }
		uiReg++;
    }
}
